</main>

<footer style="border-top:1px solid rgba(0,240,255,0.1);background:rgba(10,10,15,0.8);position:relative;z-index:1">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
                <h3 class="text-lg font-bold neon-text-cyan tracking-wider uppercase" style="font-family:'JetBrains Mono',monospace">
                    <?= htmlspecialchars($settings['site_title'] ?? 'Portfolio') ?>
                </h3>
                <p class="text-sm" style="color:#606080"><?= htmlspecialchars($settings['site_subtitle'] ?? '') ?></p>
            </div>
            <div class="flex items-center gap-3">
                <?php if (!empty($settings['github_url'])): ?>
                    <a href="<?= htmlspecialchars($settings['github_url']) ?>" target="_blank" rel="noopener" class="social-icon"><i class="fab fa-github"></i></a>
                <?php endif; ?>
                <?php if (!empty($settings['linkedin_url'])): ?>
                    <a href="<?= htmlspecialchars($settings['linkedin_url']) ?>" target="_blank" rel="noopener" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                <?php endif; ?>
                <?php if (!empty($settings['twitter_url'])): ?>
                    <a href="<?= htmlspecialchars($settings['twitter_url']) ?>" target="_blank" rel="noopener" class="social-icon"><i class="fab fa-twitter"></i></a>
                <?php endif; ?>
                <?php if (!empty($settings['dribbble_url'])): ?>
                    <a href="<?= htmlspecialchars($settings['dribbble_url']) ?>" target="_blank" rel="noopener" class="social-icon"><i class="fab fa-dribbble"></i></a>
                <?php endif; ?>
            </div>
        </div>
        <div style="border-top:1px solid rgba(0,240,255,0.05);margin-top:32px;padding-top:24px;text-align:center">
            <p class="text-sm" style="color:#404060;font-family:'JetBrains Mono',monospace;font-size:0.75rem">
                <?= htmlspecialchars($settings['footer_text'] ?? '© 2026 All Rights Reserved') ?>
            </p>
        </div>
    </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
