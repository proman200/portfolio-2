<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?= htmlspecialchars($settings['site_title'] ?? 'Portfolio') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-slate-900 text-slate-300 font-['Inter'] antialiased">

<div class="flex flex-col md:flex-row min-h-screen">
    <!-- Mobile topbar -->
    <div class="md:hidden flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/95 glass">
        <span class="font-bold text-sm bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">Admin Panel</span>
        <button id="sidebarToggle" class="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
        </button>
    </div>

    <!-- Sidebar -->
    <aside id="adminSidebar" class="admin-sidebar flex-shrink-0 hidden md:block fixed md:static top-0 left-0 z-40 -translate-x-full md:translate-x-0 transition-transform duration-300">
        <div class="p-6 border-b border-slate-700/50">
            <h2 class="text-lg font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">Admin Panel</h2>
        </div>
        <nav class="p-4 space-y-1">
            <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
                <i class="fas fa-tachometer-alt w-5"></i> Dashboard
            </a>
            <a href="projects/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/projects/') !== false ? 'active' : '' ?>">
                <i class="fas fa-folder-open w-5"></i> Projects
            </a>
            <a href="services/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/services/') !== false ? 'active' : '' ?>">
                <i class="fas fa-cogs w-5"></i> Services
            </a>
            <a href="skills/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/skills/') !== false ? 'active' : '' ?>">
                <i class="fas fa-code w-5"></i> Skills
            </a>
            <a href="experience/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/experience/') !== false ? 'active' : '' ?>">
                <i class="fas fa-briefcase w-5"></i> Experience
            </a>
            <a href="testimonials/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/testimonials/') !== false ? 'active' : '' ?>">
                <i class="fas fa-quote-right w-5"></i> Testimonials
            </a>
            <a href="blog/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/blog/') !== false ? 'active' : '' ?>">
                <i class="fas fa-blog w-5"></i> Blog
            </a>
            <a href="messages/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/messages/') !== false ? 'active' : '' ?>">
                <i class="fas fa-envelope w-5"></i> Messages
                <?php $unread = getUnreadCount(); if ($unread > 0): ?>
                    <span class="ml-auto inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-bold bg-violet-500 text-white"><?= $unread ?></span>
                <?php endif; ?>
            </a>
            <hr class="border-slate-700/50 my-3">
            <a href="settings/index.php" class="<?= strpos($_SERVER['PHP_SELF'], '/settings/') !== false ? 'active' : '' ?>">
                <i class="fas fa-cog w-5"></i> Settings
            </a>
            <hr class="border-slate-700/50 my-3">
            <a href="../index.php" target="_blank"><i class="fas fa-external-link-alt w-5"></i> View Site</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt w-5"></i> Logout</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 min-h-screen flex flex-col">
        <header class="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 h-16 border-b border-slate-800 bg-slate-900/80 glass">
            <h1 class="text-lg font-bold text-white"><?= $page_title ?? 'Dashboard' ?></h1>
            <div class="flex items-center gap-3 text-sm text-slate-400">
                <i class="fas fa-user-circle text-lg"></i>
                <span class="hidden sm:inline"><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
            </div>
        </header>
        <div class="flex-1 p-4 sm:p-8">
