<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
requireLogin();

function handleImageUpload($fieldName, $targetDir = null) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $targetDir = $targetDir ?: (__DIR__ . '/../assets/uploads/');
    $file = $_FILES[$fieldName];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

    if (!in_array($ext, $allowed)) {
        throw new Exception('File type not allowed. Allowed: ' . implode(', ', $allowed));
    }

    $filename = uniqid() . '.' . $ext;
    $dest = $targetDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new Exception('Failed to upload file.');
    }

    return 'assets/uploads/' . $filename;
}

function createSlug($title, $table, $excludeId = null) {
    global $pdo;
    $slug = slugify($title);
    $baseSlug = $slug;
    $counter = 1;

    while (true) {
        $sql = "SELECT COUNT(*) FROM $table WHERE slug = ?";
        $params = [$slug];
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        if ($stmt->fetchColumn() == 0) break;
        $slug = $baseSlug . '-' . $counter++;
    }

    return $slug;
}

function showSuccess($message) {
    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
}

function showError($message) {
    $_SESSION['flash'] = ['type' => 'error', 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function renderFlash() {
    $flash = getFlash();
    if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?>">
            <?= htmlspecialchars($flash['message']) ?>
            <button class="alert-close" onclick="this.parentElement.remove()">&times;</button>
        </div>
    <?php endif;
}
