<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app.php';

function getSettings() {
    global $pdo;
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

function getProjects($featuredOnly = false, $limit = null) {
    global $pdo;
    $sql = "SELECT * FROM projects";
    if ($featuredOnly) $sql .= " WHERE featured = 1";
    $sql .= " ORDER BY sort_order ASC, created_at DESC";
    if ($limit) $sql .= " LIMIT " . intval($limit);
    return $pdo->query($sql)->fetchAll();
}

function getProject($slug) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function getServices($limit = null) {
    global $pdo;
    $sql = "SELECT * FROM services ORDER BY sort_order ASC";
    if ($limit) $sql .= " LIMIT " . intval($limit);
    return $pdo->query($sql)->fetchAll();
}

function getService($slug) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM services WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function getSkills($category = null) {
    global $pdo;
    $sql = "SELECT * FROM skills";
    if ($category) {
        $stmt = $pdo->prepare("$sql WHERE category = ? ORDER BY sort_order ASC");
        $stmt->execute([$category]);
    } else {
        $sql .= " ORDER BY category, sort_order ASC";
        $stmt = $pdo->query($sql);
    }
    return $stmt->fetchAll();
}

function getSkillCategories() {
    global $pdo;
    return $pdo->query("SELECT DISTINCT category FROM skills ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
}

function getExperience($type = null) {
    global $pdo;
    $sql = "SELECT * FROM experience";
    if ($type) {
        $stmt = $pdo->prepare("$sql WHERE type = ? ORDER BY sort_order ASC, start_date DESC");
        $stmt->execute([$type]);
    } else {
        $sql .= " ORDER BY sort_order ASC, start_date DESC";
        $stmt = $pdo->query($sql);
    }
    return $stmt->fetchAll();
}

function getTestimonials($limit = null) {
    global $pdo;
    $sql = "SELECT * FROM testimonials ORDER BY sort_order ASC";
    if ($limit) $sql .= " LIMIT " . intval($limit);
    return $pdo->query($sql)->fetchAll();
}

function getBlogPosts($publishedOnly = true, $limit = null) {
    global $pdo;
    $sql = "SELECT * FROM blog_posts";
    if ($publishedOnly) $sql .= " WHERE published = 1";
    $sql .= " ORDER BY created_at DESC";
    if ($limit) $sql .= " LIMIT " . intval($limit);
    return $pdo->query($sql)->fetchAll();
}

function getBlogPost($slug) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE slug = ?");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function getMessages($limit = null) {
    global $pdo;
    $sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
    if ($limit) $sql .= " LIMIT " . intval($limit);
    return $pdo->query($sql)->fetchAll();
}

function getUnreadCount() {
    global $pdo;
    return $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0")->fetchColumn();
}

function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'n-a';
}

function truncate($text, $length = 150) {
    if (strlen($text) <= $length) return $text;
    $text = substr($text, 0, $length);
    return substr($text, 0, strrpos($text, ' ')) . '...';
}

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    $units = [
        31536000 => 'year', 2592000 => 'month',
        604800 => 'week', 86400 => 'day',
        3600 => 'hour', 60 => 'minute', 1 => 'second'
    ];
    foreach ($units as $seconds => $unit) {
        if ($diff < $seconds) continue;
        $count = floor($diff / $seconds);
        return "$count $unit" . ($count > 1 ? 's' : '') . ' ago';
    }
    return 'just now';
}

function old($key, $default = '') {
    return isset($_POST[$key]) ? htmlspecialchars($_POST[$key]) : $default;
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
