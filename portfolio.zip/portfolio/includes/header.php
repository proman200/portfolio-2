<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($settings['site_title'] ?? 'Portfolio') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-[#0a0a0f] text-[#c8c8d8] font-['Space_Grotesk'] antialiased">

<div class="cyber-grid"></div>

<nav class="fixed top-0 left-0 right-0 z-50" style="background:rgba(10,10,15,0.9);border-bottom:1px solid rgba(0,240,255,0.1);">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <a href="index.php" class="text-lg font-bold neon-text-cyan tracking-wider uppercase" style="font-family:'JetBrains Mono',monospace">
                <?= htmlspecialchars($settings['site_title'] ?? 'Portfolio') ?>
            </a>
            <div class="hidden md:flex items-center gap-1">
                <a href="index.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">Home</a>
                <a href="about.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">About</a>
                <a href="projects.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">Projects</a>
                <a href="services.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">Services</a>
                <a href="blog.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">Blog</a>
                <a href="contact.php" class="nav-link px-4 py-2 text-sm font-medium text-[#606080] hover:text-[#00f0ff] transition-all" style="font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase;font-size:0.7rem">Contact</a>
            </div>
            <button id="menuBtn" class="md:hidden p-2 rounded text-[#606080] hover:text-[#00f0ff] transition-all" aria-label="Menu">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
    </div>
    <div id="mobileMenu" class="hidden md:hidden" style="border-top:1px solid rgba(0,240,255,0.1)">
        <div class="px-4 py-3 space-y-1">
            <a href="index.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">Home</a>
            <a href="about.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">About</a>
            <a href="projects.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">Projects</a>
            <a href="services.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">Services</a>
            <a href="blog.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">Blog</a>
            <a href="contact.php" class="block nav-link px-4 py-3 text-sm font-medium text-[#606080] hover:text-[#00f0ff]">Contact</a>
        </div>
    </div>
</nav>

<main>
