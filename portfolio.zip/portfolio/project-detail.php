<?php
require_once 'includes/functions.php';
$settings = getSettings();
if (!isset($_GET['slug'])) redirect('projects.php');
$project = getProject($_GET['slug']);
if (!$project) redirect('projects.php');
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-4xl mx-auto">
        <div class="mb-8 reveal">
            <a href="projects.php" class="inline-flex items-center gap-2 text-sm transition-colors" style="color:#606080;font-family:'JetBrains Mono',monospace">
                <i class="fas fa-arrow-left"></i> BACK
            </a>
        </div>
        <div class="reveal">
            <span class="cyber-tag mb-4" style="font-size:0.6rem">PROJECT</span>
            <h1 class="text-4xl sm:text-5xl font-bold text-white mb-4"><?= htmlspecialchars($project['title']) ?></h1>
        </div>
        <?php if ($project['technologies']): ?>
            <div class="flex flex-wrap gap-2 mb-6 reveal reveal-delay-1">
                <?php foreach (explode(',', $project['technologies']) as $tech): ?>
                    <span class="tech-badge"><?= htmlspecialchars(trim($tech)) ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <div class="flex items-center gap-3 mb-8 reveal reveal-delay-2">
            <?php if ($project['live_url']): ?>
                <a href="<?= htmlspecialchars($project['live_url']) ?>" target="_blank" class="neon-btn neon-btn-cyan" style="padding:10px 24px"><i class="fas fa-external-link-alt"></i> Live Demo</a>
            <?php endif; ?>
            <?php if ($project['github_url']): ?>
                <a href="<?= htmlspecialchars($project['github_url']) ?>" target="_blank" class="neon-btn neon-btn-pink" style="padding:10px 24px"><i class="fab fa-github"></i> Source</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php if ($project['image_url']): ?>
<section class="px-4 reveal" style="z-index:1;position:relative">
    <div class="max-w-6xl mx-auto">
        <div class="cyber-card rounded overflow-hidden">
            <img src="<?= htmlspecialchars($project['image_url']) ?>" alt="" class="w-full h-auto max-h-[70vh] object-cover" style="display:block">
        </div>
    </div>
</section>
<?php endif; ?>

<section class="py-16 px-4 relative" style="z-index:1">
    <div class="max-w-4xl mx-auto">
        <div class="reveal">
            <div class="cyber-card rounded p-8 mb-8">
                <h2 class="text-xl font-bold text-white mb-4 cyber-border pb-4">Description</h2>
                <p class="leading-relaxed" style="color:#606080"><?= nl2br(htmlspecialchars($project['description'])) ?></p>
            </div>
        </div>
        <?php if ($project['content']): ?>
            <div class="reveal reveal-delay-1">
                <div class="cyber-card rounded p-8 rich-content">
                    <?= $project['content'] ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
