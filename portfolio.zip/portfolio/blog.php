<?php
require_once 'includes/functions.php';
$settings = getSettings();
$posts = getBlogPosts();
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h1 class="text-3xl sm:text-4xl font-bold text-white">Blog</h1>
            <div class="section-header-line"></div>
        </div>

        <?php if (empty($posts)): ?>
            <div class="text-center py-24 reveal">
                <i class="fas fa-blog text-5xl" style="color:#404060"></i>
                <p class="mt-4" style="color:#606080">No posts yet. Stay tuned!</p>
            </div>
        <?php else: ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($posts as $i => $post): ?>
                    <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                        <a href="blog-detail.php?slug=<?= $post['slug'] ?>" class="block cyber-card rounded overflow-hidden h-full group">
                            <?php if ($post['image_url']): ?>
                                <div class="h-52 overflow-hidden">
                                    <img src="<?= htmlspecialchars($post['image_url']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" style="display:block">
                                </div>
                            <?php endif; ?>
                            <div class="p-6">
                                <span class="text-xs" style="color:#606080;font-family:'JetBrains Mono',monospace"><?= date('M d, Y', strtotime($post['created_at'])) ?></span>
                                <h3 class="text-lg font-bold text-white mt-2 mb-2 transition-colors group-hover:text-[#00f0ff]"><?= htmlspecialchars($post['title']) ?></h3>
                                <p class="text-sm leading-relaxed" style="color:#606080"><?= htmlspecialchars(truncate($post['excerpt'] ?: $post['content'], 150)) ?></p>
                                <span class="inline-flex items-center gap-1 text-sm neon-text-cyan font-medium mt-4 group-hover:gap-2 transition-all">Read More <i class="fas fa-arrow-right text-xs"></i></span>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
