<?php
/**
 * Portfolio Setup Script
 * Run this once after importing database.sql to verify the setup.
 * Visit: http://localhost/portfolio/setup.php
 */

$step = isset($_GET['step']) ? intval($_GET['step']) : 1;
$error = null;
$success = null;

if ($step === 2) {
    // Test database connection
    try {
        require_once 'config/database.php';
        $success = 'Database connection successful!';
    } catch (Exception $e) {
        $error = 'Database connection failed: ' . $e->getMessage();
    }
}

if ($step === 3) {
    require_once 'config/database.php';
    try {
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        $expected = ['admin_users', 'projects', 'services', 'skills', 'experience', 'testimonials', 'blog_posts', 'contact_messages', 'site_settings'];
        $missing = array_diff($expected, $tables);
        if (empty($missing)) {
            $success = 'All tables exist! Database is ready.';
        } else {
            $error = 'Missing tables: ' . implode(', ', $missing) . '. Did you import database.sql?';
        }
    } catch (Exception $e) {
        $error = 'Error checking tables: ' . $e->getMessage();
    }
}

if ($step === 4) {
    require_once 'config/database.php';
    try {
        $stmt = $pdo->query("SELECT * FROM admin_users LIMIT 1");
        $admin = $stmt->fetch();
        if ($admin) {
            $success = 'Admin user found: ' . htmlspecialchars($admin['email']) . '. You can login at <a href="admin/index.php">admin panel</a>.';
        } else {
            $error = 'No admin user found. Make sure you imported database.sql.';
        }
    } catch (Exception $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio Setup</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .setup-container { max-width: 700px; margin: 100px auto; padding: 0 24px; }
        .setup-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); padding: 40px; }
        .setup-card h1 { margin-bottom: 8px; }
        .setup-card > p { color: var(--text-secondary); margin-bottom: 32px; }
        .setup-steps { margin-bottom: 32px; }
        .step { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid var(--border); }
        .step:last-child { border-bottom: none; }
        .step-num { width: 32px; height: 32px; border-radius: 50%; background: var(--bg-secondary); display: flex; align-items: center; justify-content: center; font-size: 0.85rem; font-weight: 700; color: var(--text-muted); flex-shrink: 0; }
        .step.done .step-num { background: var(--success); color: #fff; }
        .step.active .step-num { background: var(--accent); color: #fff; }
        .step-info { flex: 1; }
        .step-info strong { display: block; font-size: 0.95rem; }
        .step-info span { color: var(--text-muted); font-size: 0.85rem; }
        .step-status { color: var(--text-muted); font-size: 0.85rem; }
        .step.done .step-status { color: var(--success); }
        .setup-footer { margin-top: 24px; text-align: center; }
        .delete-note { margin-top: 24px; padding: 16px; background: rgba(239,68,68,0.1); border: 1px solid var(--error); border-radius: var(--radius-sm); font-size: 0.85rem; color: var(--error); }
    </style>
</head>
<body>
    <div class="setup-container">
        <div class="setup-card">
            <h1>🚀 Portfolio Setup</h1>
            <p>Follow these steps to get your portfolio up and running.</p>

            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <div class="setup-steps">
                <div class="step <?= $step > 1 ? 'done' : ($step === 1 ? 'active' : '') ?>">
                    <div class="step-num">1</div>
                    <div class="step-info">
                        <strong>Create Database</strong>
                        <span>Open phpMyAdmin, create a database named <code>portfolio_db</code></span>
                    </div>
                    <div class="step-status"><?= $step > 1 ? '✓' : '' ?></div>
                </div>
                <div class="step <?= $step > 2 ? 'done' : ($step === 2 ? 'active' : '') ?>">
                    <div class="step-num">2</div>
                    <div class="step-info">
                        <strong>Import Schema</strong>
                        <span>Import <code>database.sql</code> into the <code>portfolio_db</code> database</span>
                    </div>
                    <div class="step-status"><?= $step > 2 ? '✓' : '' ?></div>
                </div>
                <div class="step <?= $step > 3 ? 'done' : ($step === 3 ? 'active' : '') ?>">
                    <div class="step-num">3</div>
                    <div class="step-info">
                        <strong>Test Connection</strong>
                        <span>Verify PHP can connect to the database</span>
                    </div>
                    <div class="step-status"><?= $step > 3 ? '✓' : '' ?></div>
                </div>
                <div class="step <?= $step > 4 ? 'done' : ($step === 4 ? 'active' : '') ?>">
                    <div class="step-num">4</div>
                    <div class="step-info">
                        <strong>Login to Admin Panel</strong>
                        <span>Go to <code>admin/index.php</code> and sign in</span>
                    </div>
                    <div class="step-status"><?= $step > 4 ? '✓' : '' ?></div>
                </div>
            </div>

            <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <a href="setup.php?step=2" class="btn btn-primary">Test Database Connection</a>
                <a href="setup.php?step=3" class="btn <?= $step >= 2 ? 'btn-primary' : 'btn-outline' ?>">Check Tables</a>
                <a href="setup.php?step=4" class="btn <?= $step >= 3 ? 'btn-primary' : 'btn-outline' ?>">Check Admin</a>
                <a href="admin/index.php" class="btn btn-outline">Go to Admin</a>
            </div>

            <div class="setup-footer">
                <a href="index.php" class="btn btn-outline">View Public Site</a>
            </div>

            <div class="delete-note">
                <strong>⚠️ Security:</strong> Delete the <code>setup.php</code> file after setup is complete!
            </div>
        </div>
    </div>
</body>
</html>
