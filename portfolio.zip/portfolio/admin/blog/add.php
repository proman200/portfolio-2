<?php
require_once '../../includes/crud_helper.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $slug = createSlug($_POST['title'], 'blog_posts');
        $published = isset($_POST['published']) ? 1 : 0;
        $pdo->prepare("INSERT INTO blog_posts (title, slug, content, excerpt, image_url, published) VALUES (?, ?, ?, ?, ?, ?)")->execute([$_POST['title'], $slug, $_POST['content'], $_POST['excerpt'], $_POST['image_url'], $published]);
        showSuccess('Post created!'); redirect('index.php');
    } catch (Exception $e) { showError($e->getMessage()); }
}
$page_title = 'Add Blog Post';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Add Blog Post</h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <form method="POST" class="space-y-5">
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Title <span class="text-red-400">*</span></label><input type="text" name="title" required class="form-input"></div><div><label class="flex items-center gap-2 pt-7"><input type="checkbox" name="published" value="1" checked class="w-4 h-4 accent-violet-500"> <span class="text-sm text-slate-300">Published</span></label></div></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Excerpt</label><textarea name="excerpt" rows="3" class="form-input"></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Content</label><textarea name="content" id="editor" rows="15" class="form-input"></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Featured Image URL</label><input type="url" name="image_url" class="form-input" placeholder="https://..."></div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Save</button><a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Cancel</a></div>
    </form>
</div>
<script>
tinymce.init({
    selector: '#editor',
    height: 400,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table code help wordcount',
    toolbar: 'undo redo | blocks | bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | code | fullscreen',
    skin: 'oxide-dark',
    content_css: 'dark',
    promotion: false,
    branding: false,
});
</script>
<?php include '../../includes/admin_footer.php'; ?>
