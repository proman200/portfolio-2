<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();
$page_title = 'Dashboard';
$settings = getSettings();

$stats = [
    'projects' => $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn(),
    'services' => $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn(),
    'skills' => $pdo->query("SELECT COUNT(*) FROM skills")->fetchColumn(),
    'experience' => $pdo->query("SELECT COUNT(*) FROM experience")->fetchColumn(),
    'testimonials' => $pdo->query("SELECT COUNT(*) FROM testimonials")->fetchColumn(),
    'posts' => $pdo->query("SELECT COUNT(*) FROM blog_posts")->fetchColumn(),
    'messages' => $pdo->query("SELECT COUNT(*) FROM contact_messages")->fetchColumn(),
    'unread' => getUnreadCount(),
];

$recentMessages = getMessages(5);

include '../includes/admin_header.php';
?>

<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-folder-open"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['projects'] ?></p><p class="text-xs text-slate-500">Projects</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-cogs"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['services'] ?></p><p class="text-xs text-slate-500">Services</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-code"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['skills'] ?></p><p class="text-xs text-slate-500">Skills</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-briefcase"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['experience'] ?></p><p class="text-xs text-slate-500">Experience</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-quote-right"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['testimonials'] ?></p><p class="text-xs text-slate-500">Testimonials</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center text-violet-400 text-xl"><i class="fas fa-blog"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['posts'] ?></p><p class="text-xs text-slate-500">Posts</p></div></div></div>
    <div class="stat-card <?= $stats['unread'] > 0 ? 'border-amber-500/30' : '' ?>"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 text-xl"><i class="fas fa-envelope"></i></div><div><p class="text-2xl font-bold text-white"><?= $stats['messages'] ?></p><p class="text-xs text-slate-500"><?= $stats['unread'] ?> unread</p></div></div></div>
    <div class="stat-card"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 text-xl"><i class="fas fa-check-circle"></i></div><div><p class="text-2xl font-bold text-white"><?= $pdo->query("SELECT COUNT(*) FROM blog_posts WHERE published=1")->fetchColumn() ?></p><p class="text-xs text-slate-500">Published</p></div></div></div>
</div>

<!-- Recent Messages -->
<div class="glass rounded-xl overflow-hidden">
    <div class="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
        <h2 class="text-sm font-bold text-white"><i class="fas fa-clock text-violet-400 mr-2"></i> Recent Messages</h2>
        <a href="messages/index.php" class="text-xs text-violet-400 hover:text-violet-300 font-medium">View All</a>
    </div>
    <?php if (empty($recentMessages)): ?>
        <div class="p-6 text-center text-slate-500 text-sm">No messages yet.</div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Name</th><th>Email</th><th>Subject</th><th>Date</th><th></th></tr></thead>
                <tbody>
                    <?php foreach ($recentMessages as $msg): ?>
                        <tr class="<?= !$msg['is_read'] ? 'unread' : '' ?>">
                            <td class="font-medium"><?= htmlspecialchars($msg['name']) ?></td>
                            <td class="text-slate-500"><?= htmlspecialchars($msg['email']) ?></td>
                            <td><?= htmlspecialchars($msg['subject'] ?: '(No subject)') ?></td>
                            <td class="text-slate-500 text-xs"><?= date('M d, Y', strtotime($msg['created_at'])) ?></td>
                            <td><a href="messages/view.php?id=<?= $msg['id'] ?>" class="text-xs text-violet-400 hover:text-violet-300 font-medium">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/admin_footer.php'; ?>
