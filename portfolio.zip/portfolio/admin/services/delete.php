<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
showSuccess('Service deleted.');
redirect('index.php');
