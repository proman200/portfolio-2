<?php
require_once '../../includes/crud_helper.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $slug = createSlug($_POST['title'], 'services');
        $pdo->prepare("INSERT INTO services (title, slug, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)")->execute([$_POST['title'], $slug, $_POST['description'], $_POST['icon'], intval($_POST['sort_order'])]);
        showSuccess('Service created!'); redirect('index.php');
    } catch (Exception $e) { showError($e->getMessage()); }
}
$page_title = 'Add Service';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Add Service</h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <form method="POST" class="max-w-xl space-y-5">
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Title <span class="text-red-400">*</span></label><input type="text" name="title" required class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Sort Order</label><input type="number" name="sort_order" value="0" class="form-input"></div></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Description</label><textarea name="description" rows="4" class="form-input"></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Icon <span class="text-slate-600">(Font Awesome class)</span></label><input type="text" name="icon" value="fas fa-code" class="form-input"><p class="text-xs text-slate-600 mt-1">Find icons at <a href="https://fontawesome.com/icons" target="_blank" class="text-violet-400">Font Awesome</a></p></div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Save</button><a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Cancel</a></div>
    </form>
</div>
<?php include '../../includes/admin_footer.php'; ?>
