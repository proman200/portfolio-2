<?php
require_once '../includes/auth.php';

if (isLoggedIn()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (login($email, $password)) {
        redirect('dashboard.php');
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-slate-900 font-['Inter'] antialiased min-h-screen flex items-center justify-center p-4">
    <div class="absolute inset-0 pointer-events-none overflow-hidden">
        <div class="absolute top-1/4 left-1/3 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl animate-glow-pulse"></div>
        <div class="absolute bottom-1/3 right-1/4 w-64 h-64 bg-fuchsia-500/5 rounded-full blur-3xl" style="animation: float 8s ease-in-out infinite alternate;"></div>
    </div>

    <div class="relative z-10 w-full max-w-md">
        <div class="glass rounded-2xl p-8 sm:p-10">
            <div class="text-center mb-8">
                <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-violet-500/10 flex items-center justify-center">
                    <i class="fas fa-user-shield text-2xl text-violet-400"></i>
                </div>
                <h1 class="text-2xl font-bold text-white">Welcome Back</h1>
                <p class="text-slate-500 text-sm mt-1">Sign in to your admin panel</p>
            </div>

            <?php if ($error): ?>
                <div class="mb-6 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" class="space-y-5">
                <div>
                    <label class="block text-sm font-medium text-slate-400 mb-2"><i class="fas fa-envelope w-5 text-violet-400"></i> Email</label>
                    <input type="email" name="email" value="<?= old('email') ?>" required placeholder="admin@portfolio.com" class="form-input">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-400 mb-2"><i class="fas fa-lock w-5 text-violet-400"></i> Password</label>
                    <input type="password" name="password" required placeholder="Enter your password" class="form-input">
                </div>
                <button type="submit" class="w-full py-3 bg-violet-500 hover:bg-violet-600 text-white font-semibold rounded-xl transition-all shadow-lg shadow-violet-500/25 inline-flex items-center justify-center gap-2">
                    Sign In <i class="fas fa-arrow-right text-sm"></i>
                </button>
            </form>
        </div>
    </div>
</body>
</html>
