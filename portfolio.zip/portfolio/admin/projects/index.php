<?php
require_once '../../includes/crud_helper.php';
$page_title = 'Projects';
$projects = getProjects();
include '../../includes/admin_header.php';
renderFlash();
?>

<div class="glass rounded-xl overflow-hidden">
    <div class="flex items-center justify-between px-6 py-4 border-b border-slate-700/50 flex-wrap gap-3">
        <h2 class="text-sm font-bold text-white">All Projects</h2>
        <a href="add.php" class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-500 hover:bg-violet-600 text-white text-xs font-semibold rounded-lg transition-all"><i class="fas fa-plus"></i> Add Project</a>
    </div>
    <?php if (empty($projects)): ?>
        <div class="p-6 text-center text-slate-500 text-sm">No projects yet. <a href="add.php" class="text-violet-400 hover:text-violet-300">Create one</a>.</div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Title</th><th>Technologies</th><th>Featured</th><th>Date</th><th></th></tr></thead>
                <tbody>
                    <?php foreach ($projects as $p): ?>
                        <tr>
                            <td class="font-medium text-white"><?= htmlspecialchars($p['title']) ?></td>
                            <td><span class="text-slate-500"><?= htmlspecialchars(truncate($p['technologies'], 40)) ?></span></td>
                            <td><?= $p['featured'] ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-secondary">No</span>' ?></td>
                            <td class="text-xs text-slate-500"><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                            <td><div class="flex gap-1"><a href="edit.php?id=<?= $p['id'] ?>" class="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-all"><i class="fas fa-edit"></i></a><a href="delete.php?id=<?= $p['id'] ?>" class="px-3 py-1.5 text-xs font-medium bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-all" onclick="return confirm('Delete this project?')"><i class="fas fa-trash"></i></a></div></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include '../../includes/admin_footer.php'; ?>
