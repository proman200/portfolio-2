<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM projects WHERE id = ?")->execute([$id]);
showSuccess('Project deleted.');
redirect('index.php');
