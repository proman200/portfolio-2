<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?"); $stmt->execute([$id]);
$project = $stmt->fetch();
if (!$project) { showError('Not found.'); redirect('index.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $imageUrl = $project['image_url'];
        if ($_FILES['image_url']['error'] === UPLOAD_ERR_OK) { $uploaded = handleImageUpload('image_url'); if ($uploaded) $imageUrl = $uploaded; }
        $stmt = $pdo->prepare("UPDATE projects SET title=?, description=?, content=?, technologies=?, image_url=?, live_url=?, github_url=?, featured=?, sort_order=? WHERE id=?");
        $stmt->execute([$_POST['title'], $_POST['description'], $_POST['content'], $_POST['technologies'], $imageUrl, $_POST['live_url'], $_POST['github_url'], isset($_POST['featured']) ? 1 : 0, intval($_POST['sort_order']), $id]);
        showSuccess('Project updated!');
        redirect('index.php');
    } catch (Exception $e) { showError($e->getMessage()); }
}

$page_title = 'Edit Project';
include '../../includes/admin_header.php';
renderFlash();
?>

<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-sm font-bold text-white">Edit Project</h2>
        <a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a>
    </div>
    <form method="POST" enctype="multipart/form-data" class="max-w-3xl space-y-5">
        <div class="grid sm:grid-cols-2 gap-5">
            <div><label class="block text-sm font-medium text-slate-400 mb-2">Title <span class="text-red-400">*</span></label><input type="text" name="title" value="<?= htmlspecialchars($project['title']) ?>" required class="form-input"></div>
            <div><label class="block text-sm font-medium text-slate-400 mb-2">Sort Order</label><input type="number" name="sort_order" value="<?= $project['sort_order'] ?>" class="form-input"></div>
        </div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Description</label><textarea name="description" rows="4" class="form-input"><?= htmlspecialchars($project['description']) ?></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Full Content (Rich Text)</label><textarea name="content" class="tinymce"><?= htmlspecialchars($project['content']) ?></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Technologies</label><input type="text" name="technologies" value="<?= htmlspecialchars($project['technologies']) ?>" class="form-input"></div>
        <div class="grid sm:grid-cols-2 gap-5">
            <div><label class="block text-sm font-medium text-slate-400 mb-2">Live URL</label><input type="url" name="live_url" value="<?= htmlspecialchars($project['live_url']) ?>" class="form-input"></div>
            <div><label class="block text-sm font-medium text-slate-400 mb-2">GitHub URL</label><input type="url" name="github_url" value="<?= htmlspecialchars($project['github_url']) ?>" class="form-input"></div>
        </div>
        <div class="grid sm:grid-cols-2 gap-5">
            <div>
                <label class="block text-sm font-medium text-slate-400 mb-2">Image</label>
                <input type="file" name="image_url" accept="image/*" class="form-input file:text-slate-400 file:bg-transparent">
                <?php if ($project['image_url']): ?>
                    <div class="mt-2"><img src="<?= '../../' . htmlspecialchars($project['image_url']) ?>" class="h-20 rounded-lg border border-slate-700"></div>
                <?php endif; ?>
            </div>
            <div class="flex items-end pb-1"><label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="featured" value="1" <?= $project['featured'] ? 'checked' : '' ?> class="w-4 h-4 accent-violet-500"> <span class="text-sm text-slate-300">Featured</span></label></div>
        </div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50">
            <button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl transition-all"><i class="fas fa-save mr-1"></i> Update</button>
            <a href="index.php" class="px-6 py-2.5 border border-slate-700 hover:border-slate-600 text-slate-300 text-sm font-semibold rounded-xl transition-all">Cancel</a>
        </div>
    </form>
</div>

<?php include '../../includes/admin_footer.php'; ?>
