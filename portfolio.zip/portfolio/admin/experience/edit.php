<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM experience WHERE id = ?"); $stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) { showError('Not found.'); redirect('index.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->prepare("UPDATE experience SET title=?, company=?, location=?, start_date=?, end_date=?, current=?, description=?, type=?, sort_order=? WHERE id=?")
            ->execute([$_POST['title'], $_POST['company'], $_POST['location'], $_POST['start_date'], isset($_POST['current']) ? null : $_POST['end_date'], isset($_POST['current']) ? 1 : 0, $_POST['description'], $_POST['type'], intval($_POST['sort_order']), $id]);
        showSuccess('Updated!'); redirect('index.php');
    } catch (Exception $e) { showError($e->getMessage()); }
}
$page_title = 'Edit Experience';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Edit Experience</h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <form method="POST" class="max-w-xl space-y-5">
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Title <span class="text-red-400">*</span></label><input type="text" name="title" value="<?= htmlspecialchars($item['title']) ?>" required class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Company</label><input type="text" name="company" value="<?= htmlspecialchars($item['company']) ?>" class="form-input"></div></div>
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Location</label><input type="text" name="location" value="<?= htmlspecialchars($item['location']) ?>" class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Type</label><select name="type" class="form-input"><option value="work" <?= $item['type']==='work' ? 'selected' : '' ?>>Work</option><option value="education" <?= $item['type']==='education' ? 'selected' : '' ?>>Education</option></select></div></div>
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Start Date</label><input type="date" name="start_date" value="<?= $item['start_date'] ?>" class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">End Date</label><input type="date" name="end_date" value="<?= $item['end_date'] ?>" <?= $item['current'] ? 'disabled' : '' ?> class="form-input"></div></div>
        <div><label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="current" value="1" <?= $item['current'] ? 'checked' : '' ?> class="w-4 h-4 accent-violet-500"> <span class="text-sm text-slate-300">Current</span></label></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Description</label><textarea name="description" rows="4" class="form-input"><?= htmlspecialchars($item['description']) ?></textarea></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Sort Order</label><input type="number" name="sort_order" value="<?= $item['sort_order'] ?>" class="form-input"></div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Update</button><a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Cancel</a></div>
    </form>
</div>
<?php include '../../includes/admin_footer.php'; ?>
