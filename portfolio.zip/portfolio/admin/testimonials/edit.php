<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM testimonials WHERE id = ?"); $stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) { showError('Not found.'); redirect('index.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try { $pdo->prepare("UPDATE testimonials SET client_name=?, client_role=?, client_company=?, content=?, avatar_url=?, rating=?, sort_order=? WHERE id=?")->execute([$_POST['client_name'], $_POST['client_role'], $_POST['client_company'], $_POST['content'], $_POST['avatar_url'], intval($_POST['rating']), intval($_POST['sort_order']), $id]); showSuccess('Updated!'); redirect('index.php'); }
    catch (Exception $e) { showError($e->getMessage()); }
}
$page_title = 'Edit Testimonial';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Edit Testimonial</h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <form method="POST" class="max-w-xl space-y-5">
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Client Name <span class="text-red-400">*</span></label><input type="text" name="client_name" value="<?= htmlspecialchars($item['client_name']) ?>" required class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Rating</label><select name="rating" class="form-input"><?php for($i=1;$i<=5;$i++): ?><option value="<?=$i?>" <?=$item['rating']==$i?'selected':''?>><?=$i?> ⭐</option><?php endfor; ?></select></div></div>
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Role</label><input type="text" name="client_role" value="<?= htmlspecialchars($item['client_role']) ?>" class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Company</label><input type="text" name="client_company" value="<?= htmlspecialchars($item['client_company']) ?>" class="form-input"></div></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Content</label><textarea name="content" rows="4" class="form-input"><?= htmlspecialchars($item['content']) ?></textarea></div>
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Avatar URL</label><input type="url" name="avatar_url" value="<?= htmlspecialchars($item['avatar_url']) ?>" class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Sort Order</label><input type="number" name="sort_order" value="<?= $item['sort_order'] ?>" class="form-input"></div></div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Update</button><a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Cancel</a></div>
    </form>
</div>
<?php include '../../includes/admin_footer.php'; ?>
