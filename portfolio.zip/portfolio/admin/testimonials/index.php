<?php
require_once '../../includes/crud_helper.php';
$page_title = 'Testimonials';
$items = getTestimonials();
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl overflow-hidden">
    <div class="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
        <h2 class="text-sm font-bold text-white">All Testimonials</h2>
        <a href="add.php" class="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-500 hover:bg-violet-600 text-white text-xs font-semibold rounded-lg"><i class="fas fa-plus"></i> Add</a>
    </div>
    <?php if (empty($items)): ?><div class="p-6 text-center text-slate-500 text-sm">No testimonials yet.</div>
    <?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Client</th><th>Role</th><th>Rating</th><th></th></tr></thead><tbody>
            <?php foreach ($items as $item): ?><tr><td class="font-medium text-white"><?= htmlspecialchars($item['client_name']) ?></td><td class="text-xs text-slate-500"><?= htmlspecialchars($item['client_role']) ?><?= $item['client_company'] ? ', ' . htmlspecialchars($item['client_company']) : '' ?></td><td><?= str_repeat('⭐', $item['rating']) ?></td><td><div class="flex gap-1"><a href="edit.php?id=<?= $item['id'] ?>" class="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"><i class="fas fa-edit"></i></a><a href="delete.php?id=<?= $item['id'] ?>" class="px-3 py-1.5 text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></div></td></tr>
            <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</div>
<?php include '../../includes/admin_footer.php'; ?>
