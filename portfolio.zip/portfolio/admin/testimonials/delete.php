<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM testimonials WHERE id = ?")->execute([$id]);
showSuccess('Deleted.');
redirect('index.php');
