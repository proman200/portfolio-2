<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?"); $stmt->execute([$id]);
$item = $stmt->fetch();
if (!$item) { showError('Not found.'); redirect('index.php'); }
$pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?")->execute([$id]);
$page_title = 'View Message';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Message from <?= htmlspecialchars($item['name']) ?></h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <div class="grid sm:grid-cols-3 gap-4 mb-6 p-4 bg-slate-800/40 rounded-xl">
        <div><span class="text-xs text-slate-500 block">Name</span><span class="text-sm text-white"><?= htmlspecialchars($item['name']) ?></span></div>
        <div><span class="text-xs text-slate-500 block">Email</span><a href="mailto:<?= htmlspecialchars($item['email']) ?>" class="text-sm text-violet-400"><?= htmlspecialchars($item['email']) ?></a></div>
        <div><span class="text-xs text-slate-500 block">Date</span><span class="text-sm text-slate-300"><?= date('F j, Y g:i a', strtotime($item['created_at'])) ?></span></div>
    </div>
    <div><span class="text-xs text-slate-500 block mb-2">Subject</span><p class="text-sm font-medium text-white mb-4"><?= htmlspecialchars($item['subject']) ?></p></div>
    <div><span class="text-xs text-slate-500 block mb-2">Message</span><div class="text-sm text-slate-300 leading-relaxed bg-slate-800/20 rounded-xl p-4"><?= nl2br(htmlspecialchars($item['message'])) ?></div></div>
    <div class="flex gap-3 pt-4 border-t border-slate-700/50 mt-6">
        <a href="delete.php?id=<?= $item['id'] ?>" class="px-6 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm font-semibold rounded-xl" onclick="return confirm('Delete?')"><i class="fas fa-trash mr-1"></i> Delete</a>
        <a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Back to List</a>
    </div>
</div>
<?php include '../../includes/admin_footer.php'; ?>
