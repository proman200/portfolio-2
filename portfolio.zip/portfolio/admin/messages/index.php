<?php
require_once '../../includes/crud_helper.php';
$page_title = 'Messages';
$items = getMessages();
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl overflow-hidden">
    <div class="px-6 py-4 border-b border-slate-700/50"><h2 class="text-sm font-bold text-white">All Messages</h2></div>
    <?php if (empty($items)): ?><div class="p-6 text-center text-slate-500 text-sm">No messages yet.</div>
    <?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Subject</th><th>Date</th><th></th></tr></thead><tbody>
            <?php foreach ($items as $item): ?><tr class="<?= $item['is_read'] ? '' : 'bg-violet-500/5' ?>"><td class="font-medium <?= $item['is_read'] ? 'text-slate-300' : 'text-white' ?>"><?= htmlspecialchars($item['name']) ?></td><td class="text-xs"><a href="mailto:<?= htmlspecialchars($item['email']) ?>" class="text-violet-400"><?= htmlspecialchars($item['email']) ?></a></td><td class="text-xs text-slate-500"><?= htmlspecialchars($item['subject']) ?></td><td class="text-xs text-slate-500"><?= date('M j, Y g:i a', strtotime($item['created_at'])) ?></td><td><div class="flex gap-1"><a href="view.php?id=<?= $item['id'] ?>" class="px-3 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"><i class="fas fa-eye"></i></a><a href="delete.php?id=<?= $item['id'] ?>" class="px-3 py-1.5 text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a></div></td></tr>
            <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</div>
<?php include '../../includes/admin_footer.php'; ?>
