<?php
require_once '../../includes/crud_helper.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try { $pdo->prepare("INSERT INTO skills (name, category, percentage, icon, sort_order) VALUES (?, ?, ?, ?, ?)")->execute([$_POST['name'], $_POST['category'], intval($_POST['percentage']), $_POST['icon'], intval($_POST['sort_order'])]); showSuccess('Skill added!'); redirect('index.php'); }
    catch (Exception $e) { showError($e->getMessage()); }
}
$page_title = 'Add Skill';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <div class="flex items-center justify-between mb-6"><h2 class="text-sm font-bold text-white">Add Skill</h2><a href="index.php" class="text-xs text-slate-400 hover:text-violet-400"><i class="fas fa-arrow-left mr-1"></i> Back</a></div>
    <form method="POST" class="max-w-xl space-y-5">
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Name <span class="text-red-400">*</span></label><input type="text" name="name" required class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Percentage</label><input type="number" name="percentage" min="0" max="100" value="80" class="form-input"></div></div>
        <div class="grid sm:grid-cols-2 gap-5"><div><label class="block text-sm font-medium text-slate-400 mb-2">Category</label><input type="text" name="category" value="General" class="form-input"></div><div><label class="block text-sm font-medium text-slate-400 mb-2">Sort Order</label><input type="number" name="sort_order" value="0" class="form-input"></div></div>
        <div><label class="block text-sm font-medium text-slate-400 mb-2">Icon</label><input type="text" name="icon" value="fas fa-star" class="form-input"></div>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Save</button><a href="index.php" class="px-6 py-2.5 border border-slate-700 text-slate-300 text-sm font-semibold rounded-xl">Cancel</a></div>
    </form>
</div>
<?php include '../../includes/admin_footer.php'; ?>
