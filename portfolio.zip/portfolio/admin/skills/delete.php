<?php
require_once '../../includes/crud_helper.php';
$id = intval($_GET['id'] ?? 0);
$pdo->prepare("DELETE FROM skills WHERE id = ?")->execute([$id]);
showSuccess('Deleted.');
redirect('index.php');
