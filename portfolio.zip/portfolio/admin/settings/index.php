<?php
require_once '../../includes/crud_helper.php';
$settings = getSettings();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        foreach ($_POST as $key => $value) {
            if (str_starts_with($key, 'setting_')) {
                $stmt->execute([substr($key, 8), $value]);
            }
        }
        showSuccess('Settings saved!');
    } catch (Exception $e) { showError($e->getMessage()); }
    $settings = getSettings();
}
$page_title = 'Site Settings';
include '../../includes/admin_header.php';
renderFlash();
?>
<div class="glass rounded-xl p-6">
    <h2 class="text-sm font-bold text-white mb-6">Site Settings</h2>
    <form method="POST" class="space-y-6">
        <fieldset><legend class="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-3">General</legend>
            <div class="grid sm:grid-cols-2 gap-5">
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Site Title</label><input type="text" name="setting_site_title" value="<?= htmlspecialchars($settings['site_title'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Site Subtitle</label><input type="text" name="setting_site_subtitle" value="<?= htmlspecialchars($settings['site_subtitle'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Contact Email</label><input type="email" name="setting_contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Footer Text</label><input type="text" name="setting_footer_text" value="<?= htmlspecialchars($settings['footer_text'] ?? '') ?>" class="form-input"></div>
            </div>
        </fieldset>
        <fieldset><legend class="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-3">Hero Section</legend>
            <div class="grid sm:grid-cols-2 gap-5">
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Hero Title</label><input type="text" name="setting_hero_title" value="<?= htmlspecialchars($settings['hero_title'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Hero Subtitle</label><input type="text" name="setting_hero_subtitle" value="<?= htmlspecialchars($settings['hero_subtitle'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">CTA Button Text</label><input type="text" name="setting_hero_btn_text" value="<?= htmlspecialchars($settings['hero_btn_text'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">CTA Button Link</label><input type="text" name="setting_hero_btn_link" value="<?= htmlspecialchars($settings['hero_btn_link'] ?? '') ?>" class="form-input"></div>
            </div>
        </fieldset>
        <fieldset><legend class="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-3">About Section</legend>
            <div class="grid sm:grid-cols-2 gap-5">
                <div><label class="block text-sm font-medium text-slate-400 mb-2">About Title</label><input type="text" name="setting_about_title" value="<?= htmlspecialchars($settings['about_title'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">About Image URL</label><input type="url" name="setting_about_image" value="<?= htmlspecialchars($settings['about_image'] ?? '') ?>" class="form-input"></div>
            </div>
            <div class="mt-5"><label class="block text-sm font-medium text-slate-400 mb-2">About Content</label><textarea name="setting_about_content" rows="5" class="form-input"><?= htmlspecialchars($settings['about_content'] ?? '') ?></textarea></div>
        </fieldset>
        <fieldset><legend class="text-xs font-semibold text-violet-400 uppercase tracking-wider mb-3">Social Links</legend>
            <div class="grid sm:grid-cols-3 gap-4">
                <div><label class="block text-sm font-medium text-slate-400 mb-2">GitHub</label><input type="url" name="setting_github_url" value="<?= htmlspecialchars($settings['github_url'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">LinkedIn</label><input type="url" name="setting_linkedin_url" value="<?= htmlspecialchars($settings['linkedin_url'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Twitter</label><input type="url" name="setting_twitter_url" value="<?= htmlspecialchars($settings['twitter_url'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Dribbble</label><input type="url" name="setting_dribbble_url" value="<?= htmlspecialchars($settings['dribbble_url'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">Behance</label><input type="url" name="setting_behance_url" value="<?= htmlspecialchars($settings['behance_url'] ?? '') ?>" class="form-input"></div>
                <div><label class="block text-sm font-medium text-slate-400 mb-2">CodePen</label><input type="url" name="setting_codepen_url" value="<?= htmlspecialchars($settings['codepen_url'] ?? '') ?>" class="form-input"></div>
            </div>
        </fieldset>
        <div class="flex gap-3 pt-4 border-t border-slate-700/50"><button type="submit" class="px-6 py-2.5 bg-violet-500 hover:bg-violet-600 text-white text-sm font-semibold rounded-xl"><i class="fas fa-save mr-1"></i> Save Settings</button></div>
    </form>
</div>
<?php include '../../includes/admin_footer.php'; ?>
