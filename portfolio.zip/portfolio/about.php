<?php
require_once 'includes/functions.php';
$settings = getSettings();
$skills = getSkills();
$categories = getSkillCategories();
$experience = getExperience();
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h1 class="text-3xl sm:text-4xl font-bold text-white">About</h1>
            <div class="section-header-line"></div>
        </div>
        <div class="grid lg:grid-cols-5 gap-12 items-start reveal reveal-delay-1">
            <?php if (!empty($settings['about_image'])): ?>
                <div class="lg:col-span-2">
                    <div class="cyber-card rounded overflow-hidden">
                        <img src="<?= htmlspecialchars($settings['about_image']) ?>" alt="About Me" class="w-full" style="display:block">
                    </div>
                </div>
            <?php endif; ?>
            <div class="<?= !empty($settings['about_image']) ? 'lg:col-span-3' : 'lg:col-span-5' ?>">
                <h2 class="text-2xl font-bold text-white mb-4"><?= htmlspecialchars($settings['about_title'] ?? 'About Me') ?></h2>
                <div class="leading-relaxed space-y-4" style="color:#606080"><?= nl2br(htmlspecialchars($settings['about_content'] ?? '')) ?></div>
            </div>
        </div>
    </div>
</section>

<?php if (!empty($skills)): ?>
<section class="py-24 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 02</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Skills</h2>
            <div class="section-header-line"></div>
        </div>
        <?php foreach ($categories as $cat): $catSkills = array_filter($skills, fn($s) => $s['category'] === $cat); if (empty($catSkills)) continue; ?>
            <div class="mb-12 reveal">
                <h3 class="text-xs font-semibold tracking-widest uppercase mb-6 neon-text-pink" style="font-family:'JetBrains Mono',monospace">// <?= htmlspecialchars($cat) ?></h3>
                <div class="grid sm:grid-cols-2 gap-4">
                    <?php foreach ($catSkills as $skill): ?>
                        <div class="skill-item cyber-card rounded p-4">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-sm font-medium" style="color:#c8c8d8"><span class="neon-text-cyan mr-2"><i class="<?= htmlspecialchars($skill['icon'] ?? 'fas fa-star') ?>"></i></span><?= htmlspecialchars($skill['name']) ?></span>
                                <span class="text-xs font-semibold neon-text-cyan"><?= intval($skill['percentage']) ?>%</span>
                            </div>
                            <div class="skill-bar-track"><div class="skill-bar-fill" data-width="<?= intval($skill['percentage']) ?>%"></div></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($experience)): ?>
<section class="py-24 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 03</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Experience</h2>
            <div class="section-header-line"></div>
        </div>
        <div class="max-w-3xl mx-auto">
            <?php foreach ($experience as $i => $item): ?>
                <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                    <div class="flex gap-6 <?= $i !== count($experience) - 1 ? 'pb-12' : '' ?> relative">
                        <div class="flex flex-col items-center">
                            <div class="timeline-dot"></div>
                            <?php if ($i !== count($experience) - 1): ?>
                                <div class="w-0.5 flex-1" style="background:linear-gradient(180deg,rgba(0,240,255,0.3),transparent)"></div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 cyber-card rounded p-6">
                            <span class="text-xs neon-text-cyan" style="font-family:'JetBrains Mono',monospace"><?= date('M Y', strtotime($item['start_date'])) ?> — <?= $item['current'] ? 'Present' : ($item['end_date'] ? date('M Y', strtotime($item['end_date'])) : 'Present') ?></span>
                            <h3 class="text-lg font-bold text-white mt-1"><?= htmlspecialchars($item['title']) ?></h3>
                            <p class="text-sm" style="color:#606080"><?= htmlspecialchars($item['company']) ?><?= $item['location'] ? ' · ' . htmlspecialchars($item['location']) : '' ?></p>
                            <?php if ($item['description']): ?>
                                <p class="text-sm mt-3 leading-relaxed" style="color:#8080a0"><?= nl2br(htmlspecialchars($item['description'])) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
