<?php
require_once 'includes/functions.php';
$settings = getSettings();
if (!isset($_GET['slug'])) redirect('blog.php');
$post = getBlogPost($_GET['slug']);
if (!$post) redirect('blog.php');
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-4xl mx-auto">
        <div class="mb-8 reveal">
            <a href="blog.php" class="inline-flex items-center gap-2 text-sm transition-colors" style="color:#606080;font-family:'JetBrains Mono',monospace">
                <i class="fas fa-arrow-left"></i> BACK
            </a>
        </div>
        <div class="reveal">
            <span class="cyber-tag mb-4" style="font-size:0.6rem">POST</span>
            <span class="text-sm neon-text-cyan" style="font-family:'JetBrains Mono',monospace;display:block"><?= date('F d, Y', strtotime($post['created_at'])) ?></span>
            <h1 class="text-4xl sm:text-5xl font-bold text-white mt-2 mb-4"><?= htmlspecialchars($post['title']) ?></h1>
        </div>
        <?php if ($post['excerpt']): ?>
            <p class="text-lg leading-relaxed reveal reveal-delay-1" style="color:#606080"><?= htmlspecialchars($post['excerpt']) ?></p>
        <?php endif; ?>
    </div>
</section>

<?php if ($post['image_url']): ?>
<section class="px-4 reveal" style="z-index:1;position:relative">
    <div class="max-w-4xl mx-auto">
        <div class="cyber-card rounded overflow-hidden">
            <img src="<?= htmlspecialchars($post['image_url']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="w-full h-auto max-h-[60vh] object-cover" style="display:block">
        </div>
    </div>
</section>
<?php endif; ?>

<section class="py-16 px-4 relative" style="z-index:1">
    <div class="max-w-4xl mx-auto">
        <div class="reveal">
            <div class="cyber-card rounded p-8 sm:p-12 rich-content">
                <?= $post['content'] ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
