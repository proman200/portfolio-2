<?php
require_once 'includes/functions.php';
$settings = getSettings();
$featuredProjects = getProjects(true, 6);
$services = getServices(6);
$testimonials = getTestimonials(3);
$blogPosts = getBlogPosts(true, 3);
include 'includes/header.php';
?>

<!-- HERO -->
<section class="min-h-screen flex items-center justify-center relative overflow-hidden px-4 pt-24" style="z-index:1">
    <canvas id="matrix-canvas" class="absolute inset-0 w-full h-full pointer-events-none" style="opacity:0.4"></canvas>
    <div class="relative z-10 text-center max-w-3xl">
        <div class="reveal visible">
            <span class="cyber-tag mb-6">SYSTEM ONLINE</span>
            <h1 class="text-4xl sm:text-5xl md:text-7xl font-bold leading-tight mb-6 glitch-wrap">
                <span class="glitch-text text-white" data-text="Hi, I'm <?= htmlspecialchars($settings['hero_title'] ?? 'a Developer') ?>">
                    Hi, I'm <?= htmlspecialchars($settings['hero_title'] ?? 'a Developer') ?>
                </span>
            </h1>
            <div class="text-lg sm:text-xl md:text-2xl mb-4 h-8" style="color:#606080;font-family:'JetBrains Mono',monospace">
                <span id="typing-text" data-phrases='["I build digital experiences","I write clean code","I solve problems","I create full-stack apps"]'></span>
                <span class="typing-cursor"></span>
            </div>
            <p class="max-w-xl mx-auto mb-8 text-sm sm:text-base" style="color:#606080">
                <?= htmlspecialchars($settings['hero_subtitle'] ?? 'Full-stack developer passionate about building amazing digital experiences') ?>
            </p>
            <div class="flex items-center justify-center gap-4 flex-wrap">
                <?php if (!empty($settings['hero_btn_text'])): ?>
                    <a href="<?= htmlspecialchars($settings['hero_btn_link'] ?? 'projects.php') ?>" class="neon-btn neon-btn-cyan">
                        <?= htmlspecialchars($settings['hero_btn_text']) ?>
                        <i class="fas fa-arrow-right text-xs"></i>
                    </a>
                <?php endif; ?>
                <a href="contact.php" class="neon-btn neon-btn-pink">
                    <i class="fas fa-terminal text-xs"></i> Contact
                </a>
            </div>
        </div>
    </div>
</section>

<!-- FEATURED PROJECTS -->
<?php if (!empty($featuredProjects)): ?>
<section class="py-24 sm:py-32 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Featured Projects</h2>
            <div class="section-header-line"></div>
        </div>
        <div class="space-y-12">
            <?php foreach ($featuredProjects as $i => $project): ?>
                <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                    <div class="flex flex-col <?= $i % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse' ?> gap-8 items-center">
                        <?php if ($project['image_url']): ?>
                            <div class="lg:w-3/5 cyber-card rounded overflow-hidden">
                                <img src="<?= htmlspecialchars($project['image_url']) ?>" alt="<?= htmlspecialchars($project['title']) ?>" class="w-full h-64 sm:h-80 object-cover" style="display:block">
                            </div>
                        <?php endif; ?>
                        <div class="<?= $project['image_url'] ? 'lg:w-2/5' : 'w-full' ?>">
                            <?php if ($project['featured']): ?>
                                <span class="cyber-tag mb-3" style="font-size:0.6rem">FEATURED</span>
                            <?php endif; ?>
                            <h3 class="text-2xl font-bold text-white mb-3"><?= htmlspecialchars($project['title']) ?></h3>
                            <p class="mb-4 leading-relaxed" style="color:#606080"><?= htmlspecialchars(truncate($project['description'], 200)) ?></p>
                            <?php if ($project['technologies']): ?>
                                <div class="flex flex-wrap gap-2 mb-5">
                                    <?php foreach (explode(',', $project['technologies']) as $tech): ?>
                                        <span class="tech-badge"><?= htmlspecialchars(trim($tech)) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="flex items-center gap-3">
                                <a href="project-detail.php?slug=<?= $project['slug'] ?>" class="neon-btn neon-btn-cyan" style="padding:8px 20px;font-size:0.75rem">
                                    View <i class="fas fa-arrow-right text-xs"></i>
                                </a>
                                <?php if ($project['github_url']): ?>
                                    <a href="<?= htmlspecialchars($project['github_url']) ?>" target="_blank" class="social-icon"><i class="fab fa-github"></i></a>
                                <?php endif; ?>
                                <?php if ($project['live_url']): ?>
                                    <a href="<?= htmlspecialchars($project['live_url']) ?>" target="_blank" class="social-icon"><i class="fas fa-external-link-alt"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-16 reveal">
            <a href="projects.php" class="neon-btn neon-btn-pink">View All Projects <i class="fas fa-arrow-right text-xs"></i></a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- SERVICES -->
<?php if (!empty($services)): ?>
<section class="py-24 sm:py-32 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 02</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Services</h2>
            <div class="section-header-line"></div>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($services as $i => $service): ?>
                <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                    <div class="cyber-card rounded p-8 text-center h-full">
                        <div class="w-14 h-14 mx-auto mb-5 flex items-center justify-center text-2xl neon-text-cyan" style="border:1px solid rgba(0,240,255,0.1)">
                            <i class="<?= htmlspecialchars($service['icon'] ?? 'fas fa-code') ?>"></i>
                        </div>
                        <h3 class="text-lg font-bold text-white mb-3"><?= htmlspecialchars($service['title']) ?></h3>
                        <p class="text-sm leading-relaxed" style="color:#606080"><?= htmlspecialchars($service['description']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- TESTIMONIALS -->
<?php if (!empty($testimonials)): ?>
<section class="py-24 sm:py-32 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 03</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Testimonials</h2>
            <div class="section-header-line"></div>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($testimonials as $i => $testimonial): ?>
                <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                    <div class="cyber-card rounded p-8 h-full flex flex-col">
                        <div class="flex gap-1 mb-4">
                            <?php for ($s = 0; $s < $testimonial['rating']; $s++): ?>
                                <i class="fas fa-star" style="color:#ff0080;text-shadow:0 0 5px rgba(255,0,128,0.5);font-size:0.85rem"></i>
                            <?php endfor; ?>
                        </div>
                        <p class="text-sm leading-relaxed flex-1 italic" style="color:#8080a0">"<?= htmlspecialchars(truncate($testimonial['content'], 200)) ?>"</p>
                        <div class="flex items-center gap-3 mt-6 pt-4" style="border-top:1px solid rgba(0,240,255,0.05)">
                            <?php if ($testimonial['avatar_url']): ?>
                                <img src="<?= htmlspecialchars($testimonial['avatar_url']) ?>" alt="" class="w-10 h-10 rounded-full object-cover" style="border:1px solid var(--neon-cyan)">
                            <?php else: ?>
                                <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm" style="background:rgba(0,240,255,0.1);color:var(--neon-cyan);font-family:'JetBrains Mono',monospace"><?= strtoupper(substr($testimonial['client_name'], 0, 1)) ?></div>
                            <?php endif; ?>
                            <div>
                                <p class="text-white text-sm font-semibold"><?= htmlspecialchars($testimonial['client_name']) ?></p>
                                <p class="text-xs" style="color:#606080"><?= htmlspecialchars($testimonial['client_role']) ?><?= $testimonial['client_company'] ? ', ' . htmlspecialchars($testimonial['client_company']) : '' ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- BLOG -->
<?php if (!empty($blogPosts)): ?>
<section class="py-24 sm:py-32 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 04</span>
            <h2 class="text-2xl sm:text-3xl font-bold text-white">Latest Posts</h2>
            <div class="section-header-line"></div>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($blogPosts as $i => $post): ?>
                <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                    <a href="blog-detail.php?slug=<?= $post['slug'] ?>" class="block cyber-card rounded overflow-hidden h-full group">
                        <?php if ($post['image_url']): ?>
                            <div class="h-48 overflow-hidden">
                                <img src="<?= htmlspecialchars($post['image_url']) ?>" alt="" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" style="display:block">
                            </div>
                        <?php endif; ?>
                        <div class="p-6">
                            <span class="text-xs" style="color:#606080;font-family:'JetBrains Mono',monospace"><?= date('M d, Y', strtotime($post['created_at'])) ?></span>
                            <h3 class="text-lg font-bold text-white mt-2 mb-2 transition-colors group-hover:text-[#00f0ff]"><?= htmlspecialchars($post['title']) ?></h3>
                            <p class="text-sm leading-relaxed" style="color:#606080"><?= htmlspecialchars(truncate($post['excerpt'] ?: $post['content'], 150)) ?></p>
                            <span class="inline-flex items-center gap-1 text-sm neon-text-cyan font-medium mt-4 group-hover:gap-2 transition-all">Read More <i class="fas fa-arrow-right text-xs"></i></span>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
