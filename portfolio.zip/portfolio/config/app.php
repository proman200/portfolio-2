<?php
// Site URL (change this in production)
define('SITE_URL', 'http://localhost/portfolio');
define('SITE_NAME', 'My Portfolio');
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('UPLOAD_URL', SITE_URL . '/assets/uploads/');

// Date format
define('DATE_FORMAT', 'M d, Y');

// Pagination
define('PER_PAGE', 10);
