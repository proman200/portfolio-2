<?php
require_once 'includes/functions.php';
$settings = getSettings();
$services = getServices();
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h1 class="text-3xl sm:text-4xl font-bold text-white">Services</h1>
            <div class="section-header-line"></div>
        </div>

        <?php if (empty($services)): ?>
            <div class="text-center py-24 reveal">
                <i class="fas fa-cogs text-5xl" style="color:#404060"></i>
                <p class="mt-4" style="color:#606080">No services listed yet.</p>
            </div>
        <?php else: ?>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($services as $i => $service): ?>
                    <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                        <div class="cyber-card rounded p-8 text-center h-full">
                            <div class="w-16 h-16 mx-auto mb-6 flex items-center justify-center text-3xl neon-text-cyan" style="border:1px solid rgba(0,240,255,0.1)">
                                <i class="<?= htmlspecialchars($service['icon'] ?? 'fas fa-code') ?>"></i>
                            </div>
                            <h3 class="text-xl font-bold text-white mb-3"><?= htmlspecialchars($service['title']) ?></h3>
                            <p class="leading-relaxed" style="color:#606080"><?= htmlspecialchars($service['description']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
