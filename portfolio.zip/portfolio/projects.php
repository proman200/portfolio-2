<?php
require_once 'includes/functions.php';
$settings = getSettings();
$projects = getProjects();
include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h1 class="text-3xl sm:text-4xl font-bold text-white">Projects</h1>
            <div class="section-header-line"></div>
        </div>

        <?php if (empty($projects)): ?>
            <div class="text-center py-24 reveal">
                <i class="fas fa-folder-open text-5xl" style="color:#404060"></i>
                <p class="mt-4" style="color:#606080">No projects yet. Check back soon!</p>
            </div>
        <?php else: ?>
            <div class="space-y-20">
                <?php foreach ($projects as $i => $project): ?>
                    <div class="reveal reveal-delay-<?= min($i, 4) ?>">
                        <div class="flex flex-col <?= $i % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse' ?> gap-10 items-center">
                            <div class="lg:w-7/12">
                                <div class="cyber-card rounded overflow-hidden">
                                    <?php if ($project['image_url']): ?>
                                        <img src="<?= htmlspecialchars($project['image_url']) ?>" alt="<?= htmlspecialchars($project['title']) ?>" class="w-full h-72 sm:h-96 object-cover" style="display:block">
                                    <?php else: ?>
                                        <div class="w-full h-72 sm:h-96 flex items-center justify-center" style="background:rgba(0,240,255,0.03)"><i class="fas fa-image text-4xl" style="color:#404060"></i></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="lg:w-5/12">
                                <?php if ($project['featured']): ?>
                                    <span class="cyber-tag mb-3" style="font-size:0.6rem">FEATURED</span>
                                <?php endif; ?>
                                <h3 class="text-2xl sm:text-3xl font-bold text-white mb-3"><?= htmlspecialchars($project['title']) ?></h3>
                                <p class="leading-relaxed mb-5" style="color:#606080"><?= htmlspecialchars(truncate($project['description'], 250)) ?></p>
                                <?php if ($project['technologies']): ?>
                                    <div class="flex flex-wrap gap-2 mb-6">
                                        <?php foreach (explode(',', $project['technologies']) as $tech): ?>
                                            <span class="tech-badge"><?= htmlspecialchars(trim($tech)) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="flex items-center gap-3 flex-wrap">
                                    <a href="project-detail.php?slug=<?= $project['slug'] ?>" class="neon-btn neon-btn-cyan" style="padding:8px 20px;font-size:0.75rem">Details <i class="fas fa-arrow-right text-xs"></i></a>
                                    <?php if ($project['live_url']): ?>
                                        <a href="<?= htmlspecialchars($project['live_url']) ?>" target="_blank" class="neon-btn neon-btn-pink" style="padding:8px 20px;font-size:0.75rem"><i class="fas fa-external-link-alt text-xs"></i> Live</a>
                                    <?php endif; ?>
                                    <?php if ($project['github_url']): ?>
                                        <a href="<?= htmlspecialchars($project['github_url']) ?>" target="_blank" class="social-icon"><i class="fab fa-github"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
