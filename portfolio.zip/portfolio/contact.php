<?php
require_once 'includes/functions.php';
$settings = getSettings();
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (!$name || !$email || !$message) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $subject, $message]);
        $success = 'Message transmitted successfully.';
    }
}

include 'includes/header.php';
?>

<section class="pt-32 pb-16 px-4 relative" style="z-index:1">
    <div class="max-w-6xl mx-auto">
        <div class="section-header reveal">
            <span class="section-number">// 01</span>
            <h1 class="text-3xl sm:text-4xl font-bold text-white">Contact</h1>
            <div class="section-header-line"></div>
        </div>

        <div class="grid lg:grid-cols-5 gap-12">
            <div class="lg:col-span-2 reveal reveal-delay-1">
                <h2 class="text-xl font-bold text-white mb-4">Get In Touch</h2>
                <p class="mb-8 leading-relaxed" style="color:#606080">Have a project? Need a developer? Drop me a message.</p>
                
                <?php if (!empty($settings['contact_email'])): ?>
                    <div class="flex items-center gap-4 mb-4">
                        <div style="width:48px;height:48px;border:1px solid rgba(0,240,255,0.1);display:flex;align-items:center;justify-content:center;color:var(--neon-cyan)">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div>
                            <p class="text-sm" style="color:#606080">Email</p>
                            <p class="text-white font-medium"><?= htmlspecialchars($settings['contact_email']) ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="flex items-center gap-3 mt-8">
                    <?php if (!empty($settings['github_url'])): ?>
                        <a href="<?= htmlspecialchars($settings['github_url']) ?>" target="_blank" class="social-icon" style="width:44px;height:44px"><i class="fab fa-github"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['linkedin_url'])): ?>
                        <a href="<?= htmlspecialchars($settings['linkedin_url']) ?>" target="_blank" class="social-icon" style="width:44px;height:44px"><i class="fab fa-linkedin-in"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['twitter_url'])): ?>
                        <a href="<?= htmlspecialchars($settings['twitter_url']) ?>" target="_blank" class="social-icon" style="width:44px;height:44px"><i class="fab fa-twitter"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="lg:col-span-3 reveal reveal-delay-2">
                <?php if ($error): ?>
                    <div class="mb-6 px-4 py-3" style="border:1px solid rgba(255,0,128,0.2);background:rgba(255,0,128,0.05);color:var(--neon-pink);font-size:0.85rem"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="mb-6 px-4 py-3" style="border:1px solid rgba(0,240,255,0.2);background:rgba(0,240,255,0.05);color:var(--neon-cyan);font-size:0.85rem"><?= htmlspecialchars($success) ?></div>
                <?php endif; ?>
                <form method="POST" class="cyber-card rounded p-8 space-y-5">
                    <div class="grid sm:grid-cols-2 gap-5">
                        <div>
                            <label for="name" class="block text-sm font-medium mb-2" style="color:#606080;font-family:'JetBrains Mono',monospace">NAME <span style="color:var(--neon-pink)">*</span></label>
                            <input type="text" id="name" name="name" value="<?= old('name') ?>" required class="form-input">
                        </div>
                        <div>
                            <label for="email" class="block text-sm font-medium mb-2" style="color:#606080;font-family:'JetBrains Mono',monospace">EMAIL <span style="color:var(--neon-pink)">*</span></label>
                            <input type="email" id="email" name="email" value="<?= old('email') ?>" required class="form-input">
                        </div>
                    </div>
                    <div>
                        <label for="subject" class="block text-sm font-medium mb-2" style="color:#606080;font-family:'JetBrains Mono',monospace">SUBJECT</label>
                        <input type="text" id="subject" name="subject" value="<?= old('subject') ?>" class="form-input">
                    </div>
                    <div>
                        <label for="message" class="block text-sm font-medium mb-2" style="color:#606080;font-family:'JetBrains Mono',monospace">MESSAGE <span style="color:var(--neon-pink)">*</span></label>
                        <textarea id="message" name="message" rows="6" required class="form-input" style="resize:vertical"><?= old('message') ?></textarea>
                    </div>
                    <button type="submit" class="neon-btn neon-btn-cyan w-full justify-center" style="padding:14px 28px">
                        <i class="fas fa-paper-plane text-xs"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
