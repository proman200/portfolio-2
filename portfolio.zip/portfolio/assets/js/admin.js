document.addEventListener('DOMContentLoaded', () => {

  // === TINYMCE INIT ===
  if (typeof tinymce !== 'undefined' && document.querySelector('.tinymce')) {
    initTinyMCE();
  }

  // === SIDEBAR TOGGLE (mobile) ===
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('adminSidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.toggle('-translate-x-full');
    });
  }

  // === FLASH MESSAGE AUTO-DISMISS ===
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.opacity = '0';
      alert.style.transition = 'opacity 0.5s ease';
      setTimeout(() => alert.remove(), 500);
    }, 5000);
  });

  // === CONFIRM DIALOGS ===
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!confirm(el.dataset.confirm || 'Are you sure?')) {
        e.preventDefault();
      }
    });
  });

  // === CURRENT DATE FOR DATE INPUTS ===
  document.querySelectorAll('input[type="date"]').forEach(input => {
    if (!input.value) {
      input.value = new Date().toISOString().split('T')[0];
    }
  });

  // === CHECKBOX: "Current" hides end date ===
  const currentCheckbox = document.querySelector('input[name="current"]');
  const endDateInput = document.querySelector('input[name="end_date"]');
  if (currentCheckbox && endDateInput) {
    currentCheckbox.addEventListener('change', () => {
      endDateInput.disabled = currentCheckbox.checked;
      if (currentCheckbox.checked) endDateInput.value = '';
    });
  }
});

function initTinyMCE() {
  tinymce.init({
    selector: '.tinymce',
    height: 500,
    menubar: true,
    plugins: 'advlist autolink lists link image charmap preview anchor searchreplace visualblocks code fullscreen insertdatetime media table help wordcount',
    toolbar: 'undo redo | blocks | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | removeformat | code fullscreen help',
    image_title: true,
    automatic_uploads: true,
    file_picker_types: 'image',
    file_picker_callback: function(cb, value, meta) {
      const input = document.createElement('input');
      input.setAttribute('type', 'file');
      input.setAttribute('accept', 'image/*');
      input.onchange = function() {
        const file = this.files[0];
        const reader = new FileReader();
        reader.onload = function() {
          const id = 'blobid' + (new Date()).getTime();
          const blobCache = tinymce.activeEditor.editorUpload.blobCache;
          const base64 = reader.result.split(',')[1];
          const blobInfo = blobCache.create(id, file, base64);
          blobCache.add(blobInfo);
          cb(blobInfo.blobUri(), { title: file.name });
        };
        reader.readAsDataURL(file);
      };
      input.click();
    },
    content_style: `
      body {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        font-size: 16px;
        line-height: 1.8;
        color: #e2e8f0;
        background: #0f172a;
        padding: 16px;
      }
      h1, h2, h3, h4 { color: #f8fafc; font-weight: 700; }
      p { margin-bottom: 16px; color: #cbd5e1; }
      a { color: #8b5cf6; text-decoration: underline; }
      img { max-width: 100%; height: auto; border-radius: 8px; }
      pre { background: #1e293b; padding: 16px; border-radius: 8px; overflow-x: auto; border: 1px solid #334155; }
      code { background: #1e293b; padding: 2px 6px; border-radius: 4px; color: #a78bfa; }
      blockquote {
        border-left: 3px solid #8b5cf6; padding: 12px 20px; margin: 16px 0;
        background: #1e293b; border-radius: 0 8px 8px 0;
        color: #94a3b8; font-style: italic;
      }
      ul, ol { padding-left: 24px; }
      li { margin-bottom: 8px; }
    `,
    skin: 'oxide-dark',
    content_css: 'dark'
  });
}
